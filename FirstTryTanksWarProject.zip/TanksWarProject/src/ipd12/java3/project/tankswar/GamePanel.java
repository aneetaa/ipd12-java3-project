package ipd12.java3.project.tankswar;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
 *
 * @author Aneeta
 */
public class GamePanel extends JPanel implements Runnable, KeyListener {

    private Thread tankThread;
    // to show tank on JPanel
    private Tank tankObject = new Tank(this);
    private Enemy enemyObject = new Enemy(this);
    private Player playerObject = new Player(this);
    private BufferedImage bgImage;
    private boolean gameOver; // default false
    private BufferedImage gameOverImage; // gameover message
    private int level = 1;

    public GamePanel() {

        addKeyListener(this);

        try {
            bgImage = ImageIO.read(new File("bg.png"));
            gameOverImage = ImageIO.read(new File("gameOver.jpg"));
        } catch (IOException ex) {
            System.err.println("Not found image file!");
        }
    }

    @Override
    public void addNotify() {
        super.addNotify();
        setTankThread(new Thread(this));
        getTankThread().start();
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2 = (Graphics2D) g; // casting g
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON); // ضد لغزش

        setBackground(Color.BLACK);

        // to draw bachground image
        g2.drawImage(getBgImage(), 0, 0, null); // it must be first to compile first for bachground
        // we add/call all paint methods existing in other classes
        getTankObject().paint(g2);
        getEnemyObject().paint(g2);

        g2.setColor(Color.GREEN);
        Font font = new Font("arial", Font.BOLD, 15);
        g2.setFont(font);
        g2.drawString("Score: ", 30, 550);
        g2.drawString("" + getPlayerObject().getScore(), 100, 550);
        g2.drawString("Level: ", 510, 550);
        g2.drawString("" + getLevel(), 580, 550);

        // draw gameover message
        // call display function
        if (isGameOver()) {
            displayGameOver(g2);
        }

        // focus on keyListener/not o conflict with actionListener
        requestFocus();

    }

    // we add/call all move methods existing in other classes
    public void move() {
        getTankObject().moveLeftRight();
        getTankObject().moveUpDown();

        getEnemyObject().move();
        getPlayerObject().explosion();

    }

    // run the Game
    @Override
    public void run() {

        while (!isGameOver()) {
            // redo paint(Graphics g)
            repaint();
            move();
            try {
                //speed control
                Thread.sleep(10);
            } catch (InterruptedException e) {

                e.printStackTrace();
            }

        }
    }

    @Override
    public void keyTyped(KeyEvent key) {
    }

    @Override
    public void keyPressed(KeyEvent key) {
        getTankObject().keyPressed(key);
    }

    @Override
    public void keyReleased(KeyEvent key) {
        getTankObject().keyReleased(key);
    }

    // display game over message
    public void displayGameOver(Graphics2D g) {
        g.drawImage(getGameOverImage(), 150, 100, null);
    }

    /**
     * @return the tankThread
     */
    public Thread getTankThread() {
        return tankThread;
    }

    /**
     * @param tankThread the tankThread to set
     */
    public void setTankThread(Thread tankThread) {
        this.tankThread = tankThread;
    }

    /**
     * @return the tankObject
     */
    public Tank getTankObject() {
        return tankObject;
    }

    /**
     * @param tankObject the tankObject to set
     */
    public void setTankObject(Tank tankObject) {
        this.tankObject = tankObject;
    }

    /**
     * @return the enemyObject
     */
    public Enemy getEnemyObject() {
        return enemyObject;
    }

    /**
     * @param enemyObject the enemyObject to set
     */
    public void setEnemyObject(Enemy enemyObject) {
        this.enemyObject = enemyObject;
    }

    /**
     * @return the playerObject
     */
    public Player getPlayerObject() {
        return playerObject;
    }

    /**
     * @param playerObject the playerObject to set
     */
    public void setPlayerObject(Player playerObject) {
        this.playerObject = playerObject;
    }

    /**
     * @return the bgImage
     */
    public BufferedImage getBgImage() {
        return bgImage;
    }

    /**
     * @param bgImage the bgImage to set
     */
    public void setBgImage(BufferedImage bgImage) {
        this.bgImage = bgImage;
    }

    /**
     * @return the gameOver
     */
    public boolean isGameOver() {
        return gameOver;
    }

    /**
     * @param gameOver the gameOver to set
     */
    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    /**
     * @return the gameOverImage
     */
    public BufferedImage getGameOverImage() {
        return gameOverImage;
    }

    /**
     * @param gameOverImage the gameOverImage to set
     */
    public void setGameOverImage(BufferedImage gameOverImage) {
        this.gameOverImage = gameOverImage;
    }

    /**
     * @return the level
     */
    public int getLevel() {
        return level;
    }

    /**
     * @param level the level to set
     */
    public void setLevel(int level) {
        this.level = level;
    }

}
