package ipd12.java3.project.tankswar;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 *
 * @author Aneeta
 */
public class Tank implements KeyListener {

    private int x = 300;
    private int y = 350;
    private int xa;
    private int ya;
    // in order to read an image from pc
    private BufferedImage tankImage;
    // to access JPanel specifications
    private GamePanel game;

    public Tank(GamePanel game) {

        this.game = game;
        // to receive an image file from pc
        try {
            tankImage = ImageIO.read(new File("tankRight.png"));
        } catch (IOException ex) {
            System.err.println("Not found image file!");
        }
    }

    public void moveLeftRight() {

        if (x + xa > 570) {
            xa = 0;
        }
        if (x + xa < 0) {
            xa = 0;
        }

        x = x + xa;
    }

    public void moveUpDown() {

        if (y + ya > 570) {
            ya = 0;
        }
        if (y + ya < 0) {
            ya = 0;
        }

        y = y + ya;
    }

    public void paint(Graphics g) {
        //super.paint(g);
        Graphics2D g2 = (Graphics2D) g; // casting g
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON); // ضد لغزش

        // draw/show tank image
        g2.drawImage(tankImage, x, y, null);

    }

    @Override
    public void keyTyped(KeyEvent key) {
    }

    @Override
    public void keyPressed(KeyEvent key) {
        switch (key.getKeyCode()) {
            case KeyEvent.VK_LEFT:
                xa = -1;
                break;
            case KeyEvent.VK_RIGHT:
                xa = 1;
                break;
            //
            case KeyEvent.VK_UP:
                ya = -1;
                break;
            //
            case KeyEvent.VK_DOWN:
                ya = 1;
                break;
            default:
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent key) {
        xa = 0;
        ya = 0;
    }

    // get width and height of image
    public Rectangle getBounds() {
        return new Rectangle(x, y, tankImage.getWidth(), tankImage.getHeight());
    }

    // find the collision coordinates
    public boolean collision() {
        return game.getEnemyObject().getBounds().intersects(getBounds());
    }

}
