package ipd12.java3.project.tankswar;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.imageio.ImageIO;

/**
 *
 * @author Aneeta
 */
public class Enemy {

    private int x = 200;
    private int y;
    private int ya = 1;

    // in order to read an image from pc
    private BufferedImage enemyImage;
    // to access JPanel specifications
    private GamePanel game;

    public Enemy(GamePanel game) {

        this.game = game;
        // to receive an image file from pc
        try {
            enemyImage = ImageIO.read(new File("enemyDown.png"));
        } catch (IOException ex) {
            System.err.println("Not found image file!");
        }
    }

    public void move() {
        // enemy move from up to down
        setY(getY() + getYa());

        if (y + ya > 450) {
            ya = -1;
        }
        if (y + ya < 0) {
            ya = 1;
        }

    }

    public void paint(Graphics g) {
        // super.paint(g);
        Graphics2D g2 = (Graphics2D) g; // casting g
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON); // ضد لغزش

        // draw image on JPanel
        g2.drawImage(getEnemyImage(), getX(), getY(), null);
    }

    // get width and height of image
    public Rectangle getBounds() {
        return new Rectangle(getX(), getY(), getEnemyImage().getWidth(), getEnemyImage().getHeight());
    }

    public void xRandom() {
        Random rand = new Random();
        setX(rand.nextInt(600));
    }

    /**
     * @return the x
     */
    public int getX() {
        return x;
    }

    /**
     * @param x the x to set
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * @return the y
     */
    public int getY() {
        return y;
    }

    /**
     * @param y the y to set
     */
    public void setY(int y) {
        this.y = y;
    }

    /**
     * @return the ya
     */
    public int getYa() {
        return ya;
    }

    /**
     * @param ya the ya to set
     */
    public void setYa(int ya) {
        this.ya = ya;
    }

    /**
     * @return the enemyImage
     */
    public BufferedImage getEnemyImage() {
        return enemyImage;
    }

    /**
     * @param enemyImage the enemyImage to set
     */
    public void setEnemyImage(BufferedImage enemyImage) {
        this.enemyImage = enemyImage;
    }

    /**
     * @return the game
     */
    public GamePanel getGame() {
        return game;
    }

    /**
     * @param game the game to set
     */
    public void setGame(GamePanel game) {
        this.game = game;
    }

}
