package ipd12.java3.project.tankswar;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Aneeta
 */
public class MainFrame extends JFrame {

    static GamePanel game = new GamePanel();
    Menu menu = new Menu();
    static JPanel centerPanel = new JPanel();

    static void showGamePanel() {
        centerPanel.add(game);
    }

    public MainFrame() {

        // vertical menu
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.add(menu);

        add(centerPanel);

        setTitle("Game");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

    }

    public static void main(String[] args) {
        MainFrame m = new MainFrame();

    }

}
