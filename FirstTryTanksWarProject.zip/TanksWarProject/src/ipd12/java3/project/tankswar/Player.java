package ipd12.java3.project.tankswar;

public class Player {

    private GamePanel game;
    private int score;

    public Player(GamePanel game) {

        this.game = game;
    }

    public void explosion() {

        if (getGame().getTankObject().collision()) {
            //game.enemyObject.setY(0);
            //game.enemyObject.xRandom();
            //score += -10;
            getGame().setGameOver(true);
            //System.out.println(score);
        }
    }

    /**
     * @return the game
     */
    public GamePanel getGame() {
        return game;
    }

    /**
     * @param game the game to set
     */
    public void setGame(GamePanel game) {
        this.game = game;
    }

    /**
     * @return the score
     */
    public int getScore() {
        return score;
    }

    /**
     * @param score the score to set
     */
    public void setScore(int score) {
        this.score = score;
    }

}
