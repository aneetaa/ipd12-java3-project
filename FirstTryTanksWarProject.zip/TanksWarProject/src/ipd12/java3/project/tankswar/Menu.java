package ipd12.java3.project.tankswar;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author Aneeta
 */
public class Menu extends JPanel implements ActionListener {

    JButton playButton;
    JButton settingsButton;
    JButton exitButton;
    //backgroud image
    BufferedImage bgMenuImage;

    public Menu() {
        createButton();

        try {
            bgMenuImage = ImageIO.read(new File("bgMenu.png"));
        } catch (IOException ex) {
            System.err.println("Not found image file!");
        }
    }

    // some problems showing buttons in menu so that paintComponent is used
    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g; // casting g
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON); // ضد لغزش

        g2.drawImage(bgMenuImage, 0, 0, null);

    }

    public void createButton() {
        playButton = new JButton(new ImageIcon("play.png"));
        settingsButton = new JButton(new ImageIcon("settings.png"));
        exitButton = new JButton(new ImageIcon("exit.png"));

        playButton.setBounds(200, 150, 200, 50);
        settingsButton.setBounds(200, 220, 200, 50);
        exitButton.setBounds(200, 290, 200, 50);

        // run actionPerformed
        playButton.addActionListener(this);
        settingsButton.addActionListener(this);
        exitButton.addActionListener(this);

        this.add(playButton);
        this.add(settingsButton);
        this.add(exitButton);

        setLayout(null);
        setBackground(Color.BLACK);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == playButton) {
            this.setVisible(false);
            MainFrame.showGamePanel();
        }

        if (e.getSource() == settingsButton) {
            // working on it
        }

        if (e.getSource() == exitButton) {
            System.exit(0);
        }
    }

}
